import pytest

from project import get_js_code, set_no_players, get_no_players, get_seat

code = get_js_code()

def test_get_js_code():
    assert get_js_code() is not None
    assert " ".join(get_js_code()).endswith("JSON.stringify(bestHands)")

def test_set_no_players():
    # Default
    assert "players = 6,/*GAME SETTING*/" in set_no_players(get_js_code())

    # Change number of players
    no = 4
    assert f"players = {no};/*GAME SETTING*/" in set_no_players(get_js_code(), no)
    no = 3
    assert f"players = {no};/*GAME SETTING*/" in set_no_players(get_js_code(), no)
    no = 2
    assert f"players = {no};/*GAME SETTING*/" in set_no_players(get_js_code(), no)

def test_get_no_players(monkeypatch):
    for no in range(2,7):
        monkeypatch.setattr('builtins.input', lambda _: str(no))
        assert get_no_players() == no

def test_get_seat(monkeypatch):
    for no in range(1,7):
        monkeypatch.setattr('builtins.input', lambda _: str(no))
        assert get_seat() == no