# Texas Holdem Intuition
#### Video Demo:  https://youtu.be/7cSr3vGRbuc or https://www.instagram.com/reel/CvebNukv1OE/

### Description:

**Play this game:**
- Enter an integer between 2 and 6: To choose how many players will be at your table
- Enter an integer between 1 and 6: To choose your seat, based on the number of players you chose for your table

This is no folding table though&mdash;everyone is staying in until the final card!<br />
Will you win more than you lose? **Good luck!**

---
### Design Considerations

#### Texas Hold'em as a compelling project&mdash;user experience perspective

Chance is fun! People like games. And relatively few games offer the depth of meaning that Texas Hold'em does as evidenced by its frequent appearance in American pop culture.

>WHEREAS, A true phenomenon of our time, Texas Hold'em has taken the world by storm, captivating countless card enthusiasts with its **deceptively simple format** ... WHEREAS, It is said that Texas Hold'em **takes a minute to learn and a lifetime to master**, and this telling statement **underscores the high level of skill** necessary to win consistently &mdash; [Texas State Legislature describing Texas Hold'em](https://capitol.texas.gov/tlodocs/80r/billtext/html/hc00109h.htm)

#### Texas Hold'em as a compelling project&mdash;software perspective

This python project is a small but highly customizable front end for a [JavaScript project](https://github.com/wrightben/texas-holdem) I created several years ago. It puts to use many of the lessons taught in CS50P, including text replacement, libraries, user input, etc. It demonstrates reuse in more than one sense. Python libraries such as [JS2PY](https://pypi.org/project/Js2Py/) are themselves tools, but in this case these tools extend this program's abilities into other languages, which makes it possible to reuse even *more* libraries.

#### Texas Hold'em as a compelling project&mdash;behavioral science (research) perspective

It turns out that this software is less about software than it is about people&mdash;the problem it's *actually* trying to solve. People approach decisions in various states of knowing. Education, social networks, etc. influence how people make decisions in important contexts like relationships, money, and poker. Our states of knowing can theoretically be detected by observing a series of reproducable decision contexts&mdash;simple games with known outcomes. Software front ends such as this one offer low-cost and engaging ways to collect the data that can then be applied to a variety of (hopefully) positive purposes.

Perceptions of randomness, inference in human communication, speed of math calculations, and so on: Do you know as much about poker as you think you do? We'll see!

People are the problem. :grin: Human cognition is a practical problem that will remain with us no matter how intelligent machines get. So why not use the growing capabilities in computer intelligence to improve our own? Because I'm so practical, it would never make sense to rewrite the JS library in Python. But using Python for the front end does provide some continuity between this step in the research process, generating and gathering data, and the next step: analytics.

:spades: :hearts: :clubs: :diamonds:

This game collects no data that is persisted (beyond the scope of the game), analyzed, or otherwise observed by the game's author. :innocent:

---

### Project Details

#### Dependencies

- [Python - JS2PY](https://pypi.org/project/Js2Py/)
- [JavaScript - Texas Hold'em](https://github.com/wrightben/texas-holdem)

##### Files Outline

- project.py: main program file
    - main()
- test_project.py: pytest function tests
    - test_
- texas-holdem.js: javascript source code file for texas-holdem


#### Outline of program execution

- The game reads in the js source code file and concatenates it into a string variable.
- The game accepts two integers in succession:
    - It uses the first integer, number of players at the table, in a text replacement operation to alter the string of js source code. The js source code needs to know the number of players at the table.
    - It uses the second integer as your seat
- The **eval_js** method of a js2py object executes the javascript code and returns the last operation in the scope of the js as its output
    - The output from the eval_js method is stored in a python variable as a JSON string.
    - The JSON string is parsed into a dict
    - The dict includes information about the hand played, which is used to determine whether or not the chosen seat has won
- The game prints out whether the chosen seat has won or lost
- The game exits

---

#### ToDo
- [x] project.py: Requires 3 custom functions (or more)
- [x] test_project.py: Requires tests for 3 custom functions (or more)
- [x] README.md: Requires full description
    - [x] README.md: Requires video demo URL
    - [x] Submit the form
- [x] requirements.txt: Any pip-installable libraries that your project requires must be listed, one per line

---

#### Project Status: Complete

This project was created for CS50’s Introduction to Programming with Python, which is available at [pll.harvard.edu](https://pll.harvard.edu/course/cs50s-introduction-programming-python) and at [cs50.harvard.edu](https://cs50.harvard.edu/python/2022/)