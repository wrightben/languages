import js2py
import json

def get_js_code():

    CODE = "texas-holdem.js"
    f = open(CODE, "r")
    code = f.readlines()

    return code

def set_no_players(code, no=6):

    if len(code) <= 1:
        raise ValueError

    for i, el in enumerate(code):
        if "6,/*GAME SETTING*/" in el:
            code[i] = el.replace("6,/*GAME SETTING*/", f"{no},/*GAME SETTING*/")

    js_src_string  = " ".join(code)

    return js_src_string

def get_no_players():
    while True:
        try:
            no = int(input("How many players? [2-6]: ").strip())
            if no in [2,3,4,5,6]:
                break
            else:
                raise ValueError
        except:
            pass

    return no

def get_seat(seat=1,players=6):
    while True:
        try:
            no = int(input(f"What seat would you like? [1-{players}]: ").strip())
            if no in range(1,players+1):
                break
            else:
                raise ValueError
        except:
            pass

    return no


def main():
    code = get_js_code()
    players = get_no_players()
    seat = get_seat(players=players)

    # players = 6
    # seat = 1

    js = set_no_players(code, players)

    # print(players, seat, js)

    r = js2py.eval_js(js)
    y = json.loads(r)

    # print(y[0]) # Winner
    l = len(y[0])

    if l == 1:
        if (seat - 1) in y[0]:
            print(f"Seat {seat} wins! Great hand! Congratulations! 🤑")
        else:
            print(f"Seat {seat} did not win! Better luck next hand! 💸")
    else:
        y[0] = [str(x + 1) for x in y[0]]
        print(f"Seats {', '.join(y[0])} split the pot.")


    # pretty = json.dumps(y, indent=4)
    # print(pretty)


if __name__ == "__main__":
    main()



'''
VAL="project"; mkdir "${VAL}"; cd "${VAL}"; code "${VAL}.py"

check50 "cs50/problems/2022/python/${VAL}"
submit50 "cs50/problems/2022/python/${VAL}"
'''