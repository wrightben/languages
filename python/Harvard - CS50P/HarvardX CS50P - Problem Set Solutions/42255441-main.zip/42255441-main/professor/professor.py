'''
	NOTE:
	The check function is actually looking for the use of .randomint(##,##) and .randomint(###,###)
	My quirkly implementation failed this check, deservedly. :)
'''
import random

problems = [] # default 10 problems

def main():
	init() # Optionally set number of problems
	level = get_level()
	generate_problems(level)
	play_game()
	display_score()

def init(number_of_problems=10):
	for i in range(0,number_of_problems):
		problems.append([0,0,0,0])

def get_level():
	while True:
		try:
			level = int(input("Level: ").strip().lower())
			if level not in (1,2,3):
				raise ValueError
			else:
				return level
				break
		except ValueError:
			pass

def generate_integer(level):

	if level not in (1,2,3):
		raise ValueError

	match level: # lol
		case 1:
			return random.randint(0, 9)
		case 2:
			return random.randint(10, 99)
		case 3:
			return random.randint(100, 999)

def generate_problems(level):
	max_range = len(problems)
	for i in range(0,max_range):
		problems[i][0] = generate_integer(level)
		problems[i][1] = generate_integer(level)

def play_game():
	max_range = len(problems)
	for i in range(0,max_range):
		present_problem(i)

def present_problem(i):
	while True:
		try:
			# Problem Attempts
			problems[i][2] += 1

			# Problem Components
			xi = problems[i][0]
			yi = problems[i][1]
			x = str(xi)
			y = str(yi)

			# Problems Attempts Exceeded, Display Answer
			if problems[i][2] > 3:
				print(" ".join(
					(x,"+",y,"=", str(xi + yi) )
				))
				return True

			# Prompt with Problem
			guess = int( input( " ".join(
				(x,"+",y,"= ")
			) ) )

			# Correct Answer and Score ... else Retry
			if guess == (xi + yi):
				problems[i][3] = 1
				break
			else:
				raise ValueError

		except ValueError:
			print("EEE")

	return True

def display_score():
	max_range = len(problems)
	score = 0
	for i in range(0,max_range):
		score += problems[i][3]
	print("Score:", score)



if __name__ == "__main__":
    main()





'''
VAL="professor"; mkdir "${VAL}"; cd "${VAL}"; code "${VAL}.py"

check50 "cs50/problems/2022/python/${VAL}"
submit50 "cs50/problems/2022/python/${VAL}"
'''