def calculate(f1, sign, f2):
	val = 0
	match sign:
		case "+":
			val = f1 + f2
		case "-":
			val = f1 - f2
		case "*":
			val = f1 * f2
		case "/":
			val = f1 / f2

	return val

# Prompt user
f1, sign, f2 = input("Expression: ").strip().lower().split(" ")
ans = calculate( float(f1), sign, float(f2) )

print( f"{ans:,.1f}" )