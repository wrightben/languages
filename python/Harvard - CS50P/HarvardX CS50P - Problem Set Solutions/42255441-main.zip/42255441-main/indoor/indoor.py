s = input("Please provide input: ").lower()
print(s)