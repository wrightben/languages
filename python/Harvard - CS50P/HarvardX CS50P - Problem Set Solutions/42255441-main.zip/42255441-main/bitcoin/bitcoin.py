import sys
import requests

def do_args():

	l = len(sys.argv)
	f = 0.0

	if l == 1:
		sys.exit("Missing command-line argument")

	try:
		f = float(sys.argv[1])
	except:
		sys.exit("Command-line argument is not a number")

	return f;

def get_price():
	try:
		url = "https://api.coindesk.com/v1/bpi/currentprice.json"
		res = requests.get(url).json()
		rate = float(res["bpi"]["USD"]["rate_float"])
# 	except requests.RequestException:
# 		...
	except:
		sys.exit("Cannot currently get price")

# 	return 38761.0833
	return rate

def main():
	a = do_args()
	p = get_price()

	print(f"${(a * p):,.4f}")



if __name__ == "__main__":
    main()



'''
VAL="bitcoin"; mkdir "${VAL}"; cd "${VAL}"; code "${VAL}.py"

check50 "cs50/problems/2022/python/${VAL}"
submit50 "cs50/problems/2022/python/${VAL}"
'''