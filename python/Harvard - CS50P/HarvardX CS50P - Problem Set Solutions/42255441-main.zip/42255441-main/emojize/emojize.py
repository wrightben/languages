import emoji


print("Output:", emoji.emojize( input("Input: ").strip() ) )


'''
VAL="emojize"; mkdir "${VAL}"; cd "${VAL}"; code "${VAL}.py"

check50 "cs50/problems/2022/python/${VAL}"
submit50 "cs50/problems/2022/python/${VA