import re
import sys


def main():
    # print(parse(input("HTML: ")))
    print(parse('<iframe width="560" height="315" src="https://www.youtube.com/embed/xvFZjo5PgG0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>'))
    print(parse('<iframe width="560" height="315" src="https://cs50.harvard.edu/python"></iframe>'))


def parse(s):
    s.strip()

    ob = re.match(r".*?src=\"https*://w*w*w*\.*youtube.com/embed/(.*?)\".*?",s)

    if ob is None:
        return None

    grp = ob.groups()
    return f"https://youtu.be/{grp[0]}"



if __name__ == "__main__":
    main()


'''
VAL="watch"; mkdir "${VAL}"; cd "${VAL}"; code "${VAL}.py"

check50 "cs50/problems/2022/python/${VAL}"
submit50 "cs50/problems/2022/python/${VAL}"
'''