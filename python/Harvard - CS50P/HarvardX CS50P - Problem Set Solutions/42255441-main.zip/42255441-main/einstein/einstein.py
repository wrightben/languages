def main():
	m = input("Enter mass as an integer (in kilograms) ")
	m = int(m)
	print(m * 90000000000000000) #c**2

main()