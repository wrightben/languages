def main():
	names = []
	final_name = ""
	trailing_punctuation = ""
	while True:
		try:
			names.append( input("Name: ").strip() )
		except:
			l = len(names)
			if l > 1:
				trailing_punctuation = " and "
				if l >= 3:
					trailing_punctuation = ", and "
				final_name = names.pop()
			break

	print("Adieu, adieu, to ", ", ".join(names), trailing_punctuation, final_name, sep="")

	return True


if __name__ == "__main__":
	main()



'''
VAL="adieu"; mkdir "${VAL}"; cd "${VAL}"; code "${VAL}.py"

check50 "cs50/problems/2022/python/${VAL}"
submit50 "cs50/problems/2022/python/${VAL}"
'''