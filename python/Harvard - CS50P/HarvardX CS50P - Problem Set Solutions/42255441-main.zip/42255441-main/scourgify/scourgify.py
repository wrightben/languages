import sys
import csv

def main():
	fin,fout = do_args()
	table = get_csv(fin)
	table = scourgify(table)
	output_table(fout, table)


def do_args():
	l = len(sys.argv)
	if l < 3:
		sys.exit("Too few command-line arguments")
	if l > 3:
		sys.exit("Too many command-line arguments")

	fin = sys.argv[1]
	if not fin.endswith(".csv"):
		sys.exit("Not a CSV file")

	fout = sys.argv[2]
	if not fout.endswith(".csv"):
		sys.exit("Not a CSV file")

	return [fin,fout]


def get_csv(arg=""):

	if arg == "":
		sys.exit("File does not exist")

	table = []
	try:
		with open(arg, "r") as file:
			reader = csv.reader(file)
			for i in reader:
				table.append(i)
	except FileNotFoundError:
		sys.exit(f"Could not read {arg}")

	return table


def scourgify(table=[]):
	table.pop(0) # Remove Headers
	new_table = [["first","last","house"]]
	for i in table:
		last, first = i[0].split(", ")
		new_table.append([ first, last, i[1] ])

	return new_table


def output_table(fout="output.csv", table=[]):
	with open(fout, 'w', newline='') as f:
		writer = csv.writer(f)
		writer.writerows(table)



if __name__ == "__main__":
    main()


'''
VAL="scourgify"; mkdir "${VAL}"; cd "${VAL}"; code "${VAL}.py"

check50 "cs50/problems/2022/python/${VAL}"
submit50 "cs50/problems/2022/python/${VAL}"
'''