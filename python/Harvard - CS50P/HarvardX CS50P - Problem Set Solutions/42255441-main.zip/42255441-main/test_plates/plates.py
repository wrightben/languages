def main():
    plate = input("Plate: ").strip()
    if is_valid(plate):
        print("Valid")
    else:
        print("Invalid")


def is_valid(s):
	if type(s) != str:
		raise TypeError

	#FILTER:

	# 1. Letters and Numbers only
	if not s.isalnum():
		return False

	# 2. Length
	_len = len(s)
	if _len > 6 or _len < 2:
		return False

	# 3. First 2 characters are letters
	if not (s[0].isalpha() and s[1].isalpha()):
		return False

	# 4a. First number cannot be zero
    # 4b. No letters after numbers
	digits = False
	for i in range(2,_len):
		if digits == False and s[i].isdigit():
			digits = True
			if int(s[i]) == 0:
				return False
		if digits == True and s[i].isalpha():
			return False


	return True


if __name__ == "__main__":
    main()