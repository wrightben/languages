from plates import is_valid


def test_is_valid_first_two_characters_are_letters():
    assert is_valid("WW") == True
    assert is_valid("ww") == True
    assert is_valid("w7") == False
    assert is_valid("7w") == False

def test_is_valid_length():
    assert is_valid("w") == False
    assert is_valid("wh7") == True
    assert is_valid("wh70000") == False

def test_is_valid_number_placement():
    assert is_valid("wh700w") == False

def test_is_valid_leading_zero():
    assert is_valid("wh000") == False

def test_is_valid_alphanumeric():
    assert is_valid("wh700.") == False