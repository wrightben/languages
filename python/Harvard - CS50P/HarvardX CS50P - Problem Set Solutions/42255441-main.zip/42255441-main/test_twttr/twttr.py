def main():
    user_input = input("Input: ").strip()
    print(shorten(user_input))


def shorten(word):
    l = []
    for c in word:
        if (c not in "aeiouAEIOU"):
            l.append(c)
    return str("".join(l))


if __name__ == "__main__":
    main()