from twttr import shorten

def test_shorten_with_str():
    assert shorten("wicked") == "wckd"

def test_shorten_with_cap():
    assert shorten("WICKED AIOLI") == "WCKD L"

def test_shorten_with_num():
    assert shorten("wicked num 2") == "wckd nm 2"

def test_shorten_with_pun():
    assert shorten("wicked!!") == "wckd!!"