import sys

def main():
	arg = do_args()
	contents = get_file_contents(arg)
	lines = count_code_lines(contents)
	print(lines[0])

def do_args():
	l = len(sys.argv)
	if l == 1:
		sys.exit("Too few command-line arguments")
	if l > 2:
		sys.exit("Too many command-line arguments")

	arg = sys.argv[1]
	if not arg.endswith(".py"):
		sys.exit("Not a python file")

	return arg

def get_file_contents(arg=""):

	if arg == "":
		sys.exit("File does not exist")

	try:
		with open(arg, "r") as file:
			lines = file.readlines()
	except FileNotFoundError:
		sys.exit("File does not exist")

	return lines

def count_code_lines(contents=[]):

	_code = 0
	_blank = 0
	_comment = 0

	for line in contents:
		line = line.strip()

		# Blank lines, Comment lines
		if line == "":
			_blank += 1
			continue
		if line[0] == "#":
			_comment += 1
			continue

		# Code
		_code += 1

	return [_code, _comment, _blank]



if __name__ == "__main__":
    main()


'''
VAL="lines"; mkdir "${VAL}"; cd "${VAL}"; code "${VAL}.py"

check50 "cs50/problems/2022/python/${VAL}"
submit50 "cs50/problems/2022/python/${VAL}"
'''