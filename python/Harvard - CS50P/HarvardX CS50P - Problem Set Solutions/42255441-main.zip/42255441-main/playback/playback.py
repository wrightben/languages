s = input("Please provide input: ").replace(" ","...")
print(s)