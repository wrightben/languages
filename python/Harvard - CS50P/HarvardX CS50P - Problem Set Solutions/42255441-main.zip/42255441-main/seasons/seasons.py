import sys
import re
import inflect
from datetime import date,time,datetime


def get_birthday(_date=None):

    return_object = []

    try:
        if _date == None:
            _date = input("Date of Birth: ").strip()

        ob = re.match(r"(\d\d\d\d)-(\d\d)-(\d\d)",_date)

        if ob is None:
            sys.exit("Invalid date")

        grp = ob.groups()

        return_object.append(int(grp[0]))
        return_object.append(int(grp[1]))
        return_object.append(int(grp[2]))

    except:
        sys.exit("Invalid date")

    return return_object

def get_minutes(_date):
    try:
        today = date.today()
        bday = date.fromisoformat(f"{_date[0]}-{_date[1]:02}-{_date[2]:02}")
        mid = time.fromisoformat('00:00:00')
        beg = datetime.combine(bday, mid)
        end = datetime.combine(today, mid)
        min = round((end - beg).total_seconds() / 60)
    except:
        raise ValueError

    return min


def main():
    _date = get_birthday()
    min = get_minutes(_date)
    p = inflect.engine()
    print(p.number_to_words(min, andword="").capitalize(),"minutes")






if __name__ == "__main__":
    main()



'''
VAL="seasons"; mkdir "${VAL}"; cd "${VAL}"; code "${VAL}.py"

check50 "cs50/problems/2022/python/${VAL}"
submit50 "cs50/problems/2022/python/${VAL}"
'''