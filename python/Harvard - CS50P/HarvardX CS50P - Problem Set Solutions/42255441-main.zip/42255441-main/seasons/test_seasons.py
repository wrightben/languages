import pytest
from seasons import get_birthday, get_minutes


def test_get_birthday():
    assert get_birthday("2023-08-02") == [2023,8,2]

def test_get_minutes():
    assert get_minutes([2022,8,2] ) == 525600
    assert get_minutes([2021,8,2] ) == 525600 * 2
    assert get_minutes([2020,8,2] ) == 525600 * 3

def test_get_minutes_raise_error():
    with pytest.raises(TypeError):
        get_minutes()
    with pytest.raises(ValueError):
        get_minutes("cat")