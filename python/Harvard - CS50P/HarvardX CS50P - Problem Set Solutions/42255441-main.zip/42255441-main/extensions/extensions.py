def get_extension(ext="null"):
# 	print(ext)
	match ext:
		case "gif":
			ext = "image/gif"
		case "jpg" | "jpeg":
			ext = "image/jpeg"
		case "png":
			ext = "image/png"
		case "pdf":
			ext = "application/pdf"
		case "txt":
			ext = "text/plain"
		case "zip":
			ext = "application/zip"
		case _:
			ext = "application/octet-stream"

	print(ext)

# Get File name components
beg,sep,end = input("File name: ").strip().lower().rpartition(".")

ext = ""
if beg != "":
	ext = end
get_extension(ext)


# Tests
# get_extension("gif")
# get_extension("jpg")
# get_extension("jpeg")
# get_extension("png")
# get_extension("pdf")
# get_extension("txt")
# get_extension("zip")
# get_extension("other")