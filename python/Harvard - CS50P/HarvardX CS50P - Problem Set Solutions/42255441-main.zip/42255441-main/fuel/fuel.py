def prompt(prompt):
	while True:
		try:
			_ = input(prompt).strip().lower()
			components = _.split("/")
			a = int(components[0])
			b = int(components[1])
			if (a > b):
				raise ValueError
			return (a, b, a/b)
			break;
		except ValueError:
			pass
		except ZeroDivisionError:
			pass

def get_display_value(c):
	if c <= 1/100:
		return "E"
	elif c >=99/100:
		return "F"
	else:
		return format(c, ".0%")


(a,b,c) = prompt("Fraction: ")
# print(a,b,c)
print( get_display_value(c) )




'''
VAL="fuel"; mkdir "${VAL}"; cd "${VAL}"; code "${VAL}.py"

check50 "cs50/problems/2022/python/${VAL}"
submit50 "cs50/problems/2022/python/${VAL}"
'''