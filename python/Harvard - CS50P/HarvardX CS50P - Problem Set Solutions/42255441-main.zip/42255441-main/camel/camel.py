user_input = input("camelCase: ").strip()
print("snake_case: ", end="")
for c in user_input:
    if not c.islower():
        print("_", end="")
        c = c.lower()
    print(c, end="")
print()