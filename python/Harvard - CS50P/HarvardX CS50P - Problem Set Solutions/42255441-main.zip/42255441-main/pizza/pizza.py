import sys
import csv
import tabulate

def main():
	arg = do_args()
	table = get_csv(arg)
	output_table(table)


def do_args():
	l = len(sys.argv)
	if l == 1:
		sys.exit("Too few command-line arguments")
	if l > 2:
		sys.exit("Too many command-line arguments")

	arg = sys.argv[1]
	if not arg.endswith(".csv"):
		sys.exit("Not a CSV file")

	return arg


def get_csv(arg=""):

	if arg == "":
		sys.exit("File does not exist")

	table = []
	try:
		with open(arg, "r") as file:
			reader = csv.reader(file)
			for i in reader:
				table.append(i)
	except FileNotFoundError:
		sys.exit("File does not exist")

	return table


def output_table(table):
	headers = table.pop(0)
	print(tabulate.tabulate(table, headers, tablefmt="grid"))


if __name__ == "__main__":
    main()


'''
VAL="pizza"; mkdir "${VAL}"; cd "${VAL}"; code "${VAL}.py"

check50 "cs50/problems/2022/python/${VAL}"
submit50 "cs50/problems/2022/python/${VAL}"
'''