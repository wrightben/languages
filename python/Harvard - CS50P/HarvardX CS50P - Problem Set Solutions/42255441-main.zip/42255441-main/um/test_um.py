import pytest
from um import count


def test_count_basic():
    assert count("um") == 1
    assert count("um?") == 1
    assert count("It's not uncommon, in English, at least, um to say 'um' when trying to, um, think of a word") == 3
    assert count("yummy") == 0
    assert count("umbro") == 0

def test_count_case_insensitive():
    assert count("UM, Um, uM") == 3

def test_count_error():
    ...
    # with pytest.raises(ValueError):
    #     convert("9 AM - 5 PM")
    # with pytest.raises(ValueError):
    #     convert("09:00 AM - 17:00 PM")