import re
import sys


def main():
    print(count(input("Text: ")))


def count(s):
    s = s.strip().lower()

    _count = 0
    for m in re.finditer(r"\b(um)\b", s):
        _count += 1

    return _count


if __name__ == "__main__":
    main()


'''
VAL="um"; mkdir "${VAL}"; cd "${VAL}"; code "${VAL}.py"

check50 "cs50/problems/2022/python/${VAL}"
submit50 "cs50/problems/2022/python/${VAL}"
'''