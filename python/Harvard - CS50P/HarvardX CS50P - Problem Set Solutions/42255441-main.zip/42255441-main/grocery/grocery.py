grocery_list = {}

def prompt():

	while True:
		try:
			_ = input().strip().lower()
			_ = _.upper()

			if _ in grocery_list:
				grocery_list[_] += 1
			else:
				grocery_list[_] = 1

		except EOFError:
			print_grocery_list()
			return True
		except ValueError:
			pass
		except ZeroDivisionError:
			pass
		except KeyError:
			pass

def print_grocery_list():
	for item in sorted (grocery_list.keys()):
		print(f"{grocery_list[item]} {item}")

prompt()


'''
VAL="grocery"; mkdir "${VAL}"; cd "${VAL}"; code "${VAL}.py"

check50 "cs50/problems/2022/python/${VAL}"
submit50 "cs50/problems/2022/python/${VAL}"
'''