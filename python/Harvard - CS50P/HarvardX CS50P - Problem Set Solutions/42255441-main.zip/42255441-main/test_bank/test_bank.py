from bank import value

def test_value_hello():
        assert value("Hello") == 0

def test_value_hey():
        assert value("Hey") == 20

def test_value_other():
        assert value("What's up") == 100