months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
]

def prompt():

	while True:
		try:
			_ = input("Date: ").strip().lower()

			# September 12, 1959
			a = _.find(",")
			b = _.find("/")

			# , Date
			if (a > -1):
				(md, y) = _.split(",")
				y = y.strip()
				(m, d) = md.split(" ")
				if int(d) < 0 or int(d) > 31:
					raise ValueError
				if m.title() in months:
					m = months.index(m.title()) + 1
					print( y+"-"+format(m, '02d')+"-"+format(int(d), '02d') )
					return
			# / Date
			elif (b > -1):
				(m,d,y) = _.split("/")
				m = m.strip()
				if int(m) < 0 or int(m) > 12:
					raise ValueError
				if int(d) < 0 or int(d) > 31:
					raise ValueError
				d = d.strip()
				y = y.strip()
				print( y+"-"+format(int(m), '02d')+"-"+format(int(d), '02d') )
				return

# 		except EOFError:
# 			return False
		except ValueError:
			pass
# 		except ZeroDivisionError:
# 			pass
# 		except KeyError:
# 			pass


prompt()




'''
VAL="outdated"; mkdir "${VAL}"; cd "${VAL}"; code "${VAL}.py"

check50 "cs50/problems/2022/python/${VAL}"
submit50 "cs50/problems/2022/python/${VAL}"
'''