'''
    NOTE:
    Despite the assignment instructions, I limited the upper bound of the game to 100.
'''
import random

def set_level():
	while True:
		try:
			level = int(input("Level: ").strip().lower())
			if level < 1 or level > 100:
				raise ValueError
			else:
				return level
				break
		except ValueError:
			pass

def do_guess(number=10, guess=1):

	number = random.randint(1, number) # [1..number] inclusive

	while True:
		try:
# 			print(number, guess) # DEBUG
			guess = int(input("Guess: ").strip().lower())

			if guess == number:
				print("Just right!")
				break
			elif guess > number:
				print("Too large!")
			elif guess < number:
				print("Too small!")

		except ValueError:
			pass

	return True


def main():
	do_guess(set_level())


if __name__ == "__main__":
	main()



'''
VAL="game"; mkdir "${VAL}"; cd "${VAL}"; code "${VAL}.py"

check50 "cs50/problems/2022/python/${VAL}"
submit50 "cs50/problems/2022/python/${VAL}"
'''