import sys
from PIL import Image, ImageOps

def main():
	fin,fout = do_args()
	overlay_image(fin,fout)

def do_args():
	l = len(sys.argv)
	if l < 3:
		sys.exit("Too few command-line arguments")
	if l > 3:
		sys.exit("Too many command-line arguments")

	fin = sys.argv[1]
	fout = sys.argv[2]
	extensions = [
		fin.endswith(".jpg"),
		fin.endswith(".png"),
		fout.endswith(".jpg"),
		fout.endswith(".png")
	]

	if (not extensions[0]) and (not extensions[1]):
		sys.exit("Invalid input")

	if (not extensions[2]) and (not extensions[3]):
		sys.exit("Invalid input")

	if (not extensions[0] == extensions[2]) and (not extensions[1] == extensions[3]):
		sys.exit("Input and output have different extensions")

	return [fin,fout]


def overlay_image(fin="",fout=""):

    if fin == "":
        sys.exit("File does not exist")

    try:
        mask = Image.open("shirt.png")
        photo = Image.open(fin)
        photo = ImageOps.fit(photo,(mask.size[0],mask.size[1]))
        photo.paste(im=mask, mask=mask)
        photo.save(fout)
    except FileNotFoundError:
        sys.exit(f"Could not read {fin}")

    return True




if __name__ == "__main__":
    main()


'''
VAL="shirt"; mkdir "${VAL}"; cd "${VAL}"; code "${VAL}.py"

check50 "cs50/problems/2022/python/${VAL}"
submit50 "cs50/problems/2022/python/${VAL}"
'''