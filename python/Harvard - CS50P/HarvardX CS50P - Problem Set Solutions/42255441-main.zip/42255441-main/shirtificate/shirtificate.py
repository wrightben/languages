from fpdf import FPDF


name = input("Name: ").strip().lower().title()


def make_pdf():
	pdf = FPDF()
	pdf.add_page()

	# Image
	pdf.image("shirtificate.png",15,80,177,0)

	# Bold Text
# 	pdf.set_font("helvetica", "B", 36)
	pdf.set_font("helvetica", "", 48)
	pdf.cell(w=190, h=40, txt="CS50 Shirtificate", align='c')

	# Move Down
	pdf.set_x(10)
	pdf.set_y(120)

	# White Text
	pdf.set_font("helvetica", "", 20)
	pdf.set_text_color(255, 255, 255)
	pdf.cell(w=190, h=40, txt=f"{name} took CS50", align="c")

	# Write PDF
	pdf.output("shirtificate.pdf")

	return True

def main():
	make_pdf()

if __name__ == "__main__":
    main()


'''
VAL="shirtificate"; mkdir "${VAL}"; cd "${VAL}"; code "${VAL}.py"

check50 "cs50/problems/2022/python/${VAL}"
submit50 "cs50/problems/2022/python/${VAL}"
'''