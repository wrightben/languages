emoji = "🍪"

class Jar:
    _capacity = 12
    _balance = 0

    @classmethod
    def positive_amount(cls, amt=0):
        if amt < 0:
            raise ValueError
        return amt

    def __init__(self, capacity=12):
        capacity = Jar.positive_amount(capacity)
        self._capacity = capacity

    def __str__(self):
        return emoji * self._balance

    def deposit(self, n):
        n = Jar.positive_amount(n)
        if n + self._balance > self._capacity:
            raise ValueError
        self._balance += n
        return self._balance

    def withdraw(self, n):
        n = Jar.positive_amount(n)
        if self._balance - n < 0:
            raise ValueError
        self._balance -= n
        return self._balance

    @property
    def capacity(self):
        return self._capacity

    @property
    def size(self):
        return self._balance

def main():
    j = Jar(5)
    j.deposit(4)
    j.withdraw(2)
    print(j, j.capacity )



if __name__ == "__main__":
    main()




'''
VAL="jar"; mkdir "${VAL}"; cd "${VAL}"; code "${VAL}.py"

check50 "cs50/problems/2022/python/${VAL}"
submit50 "cs50/problems/2022/python/${VAL}"
'''