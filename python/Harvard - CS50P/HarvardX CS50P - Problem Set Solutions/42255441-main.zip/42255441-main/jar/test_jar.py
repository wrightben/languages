import pytest
from jar import Jar


j = Jar(5)

def test_str():
    jar = Jar()
    assert str(jar) == ""
    jar.deposit(1)
    assert str(jar) == "🍪"
    jar.deposit(11)
    assert str(jar) == "🍪🍪🍪🍪🍪🍪🍪🍪🍪🍪🍪🍪"

def test_init():
    assert str(j) == ""

def test_deposit():
    assert j.deposit(5) == 5

def test_withdraw():
    assert j.withdraw(2) == 3

def test_capacity():
    assert j.capacity == 5

def test_size():
    assert j.size == 3

def test_positive_amount1():
    with pytest.raises(ValueError):
        j.withdraw(10)

def test_positive_amount2():
    with pytest.raises(ValueError):
        j.deposit(15)

def test_positive_amount3():
    with pytest.raises(ValueError):
        Jar(-5)