# def prompt(greeting=input("Greeting: ").strip().lower()): # This shows python is setting the default parameter before the argument
def prompt(greeting=0):

    if greeting == 0:
        greeting=input("Greeting: ")

    greeting = greeting.strip().lower()

    if greeting.startswith("hello"):
        print("$0")
    elif greeting.startswith("h"):
        print("$20")
    else:
        print("$100")


prompt()
# prompt("Hello")
# prompt("Hello, Newman")
# prompt("How you doing?")
# prompt("What's happening?")