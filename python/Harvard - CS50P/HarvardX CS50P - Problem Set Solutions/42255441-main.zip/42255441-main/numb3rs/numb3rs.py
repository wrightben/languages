import re
import sys


def main():
	print(validate(input("IPv4 Address: ")))

def validate(ip):

    ip.strip()
    
    ob = re.match(r"^(\d+)\.(\d+)\.(\d+)\.(\d+)$",ip)

    if ob is None:
        return False

    grp = ob.groups()
    l = len(grp)

    if (l != 4):
        return False

    for i in grp:
        if int(i) not in range(0,256):
            return False

    return True


if __name__ == "__main__":
    main()


'''
VAL="numb3rs"; mkdir "${VAL}"; cd "${VAL}"; code "${VAL}.py"

check50 "cs50/problems/2022/python/${VAL}"
submit50 "cs50/problems/2022/python/${VAL}"
'''