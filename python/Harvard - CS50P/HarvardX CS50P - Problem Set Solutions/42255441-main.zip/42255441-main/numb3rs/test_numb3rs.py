import pytest
from numb3rs import validate


def test_validate_is_within_range():
    assert validate("251.252.253.254") == True
    assert validate("251.252.253.275") == False

def test_validate_is_valid_ip():
    assert validate("cat") == False
    assert validate("123.123.123.") == False
    assert validate("123.123") == False