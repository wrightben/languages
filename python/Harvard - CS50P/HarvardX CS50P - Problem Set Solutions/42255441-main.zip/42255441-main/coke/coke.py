def main(user_input=""):
	due = 50
	received = 0
	while(received < due):
		print("Amount Due: ", due - received, sep="")
		user_input = int(input("Insert Coin: ").strip().lower())
		match user_input:
			case 25:
				received += user_input
			case 10:
				received += user_input
			case 5:
				received += user_input
	print("Change Owed: ", received - due, sep="" )

if __name__ == "__main__":
    main()