def main(user_input=""):
	if user_input == "":
		user_input = input("What time is it? ").strip().lower()

	if not ":" in user_input: # Not a time
		return False

	segments = user_input.split(" ") #(time, [am|pm])

	time = segments[0]
	hours, minutes = get_hours_minutes(time)
	hours = int(hours)
	minutes = int(minutes)

	if len(segments) > 1:
		if 	(segments[1] == "p.m." or segments[1] == "pm") and hours != 12:
# 			print( segments[1] )
			hours = int(hours) + 12

	seconds = get_hours_minutes_as_seconds( hours, minutes )
	to_seconds_constant = 60 * 60

# 	print( seconds )

	if seconds >= (7 * to_seconds_constant) and seconds <= (8 * to_seconds_constant):
		print("breakfast time")
	elif seconds >= (12 * to_seconds_constant) and seconds <= (13 * to_seconds_constant):
		print("lunch time")
	elif seconds >= (18 * to_seconds_constant) and seconds <= (19 * to_seconds_constant):
		print("dinner time")


# 	print( hours, minutes )
# 	print( get_hours_minutes_as_seconds( hours, minutes ) )
# 	print( convert(time) )

	return True


def convert(time):
	hours, minutes = get_hours_minutes(time)
	return float(hours) + (float(minutes)/60)

def get_hours_minutes(time):
	time = time.split(":")
	hours = time[0]
	minutes = time[1]
	return (hours, minutes)

def get_hours_minutes_as_seconds(hours, minutes):
	seconds = 0
	seconds = hours * 60 * 60
	seconds += (int(minutes) * 60)
	return seconds


if __name__ == "__main__":
    main()


# main("7:00") # breakfast time
# main("7:30") # breakfast time
# main("12:42") # lunch time
# main("18:32") # dinner time
# main("11:11") # (null)