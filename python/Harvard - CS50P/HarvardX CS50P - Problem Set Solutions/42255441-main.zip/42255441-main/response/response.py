import validators

def main():
    s = input("What's your email address? ").strip().lower()
    print(is_valid(s))

    # s = "malan@harvard.edu"
    # print(is_valid(s))
    # s = "sysadmins@cs50.harvard.edu"
    # print(is_valid(s))
    # s = "malan at harvard dot edu"
    # print(is_valid(s))
    # s = "malan@@@harvard.edu"
    # print(is_valid(s))

def is_valid(s):

    try:
        if validators.email(s):
            return "Valid"
    except:
        pass

    return "Invalid"


if __name__ == "__main__":
    main()


'''
VAL="response"; mkdir "${VAL}"; cd "${VAL}"; code "${VAL}.py"

check50 "cs50/problems/2022/python/${VAL}"
submit50 "cs50/problems/2022/python/${VAL}"
'''