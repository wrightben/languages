def convert(_str):
	print(
		_str
			.replace(":)","🙂")
			.replace(":(","🙁")
	)

def main():
	i = input("Enter ")
	convert(i)

main()