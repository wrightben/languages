import sys
import random
from pyfiglet import Figlet
figlet = Figlet()
fonts = figlet.getFonts()
error_message = "Invalid usage"

def do_args():

	l = len(sys.argv)
	lf = len(fonts)

	if l == 1:
		print("0 argv")
		ri = random.randint(0, lf - 1)
		figlet.setFont(font=fonts[ri])
	elif l == 3:
		if (sys.argv[1] != "-f" and sys.argv[1] != "-font"):
			sys.exit(error_message)
		else:
			specified_font = sys.argv[2]
			if not specified_font in fonts:
				sys.exit(error_message)
			else:
				figlet.setFont(font=specified_font)
	else:
		sys.exit(error_message)


def main():
	do_args()

	_ = input("Input: ").strip()

	print(figlet.renderText(_))

	return True


if __name__ == "__main__":
	main()



'''
VAL="figlet"; mkdir "${VAL}"; cd "${VAL}"; code "${VAL}.py"

check50 "cs50/problems/2022/python/${VAL}"
submit50 "cs50/problems/2022/python/${VAL}"
'''