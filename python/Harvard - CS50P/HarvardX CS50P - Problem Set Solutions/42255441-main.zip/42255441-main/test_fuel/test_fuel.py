import pytest
from fuel import convert, gauge


def test_convert():
    assert convert("3/5") == 60

def test_convert_value_error():
    with pytest.raises(ValueError):
        convert("cat")
    with pytest.raises(ValueError):
        convert("cat/3")
    with pytest.raises(ZeroDivisionError):
        convert("3/0")

def test_gauge():
    assert gauge(1) == "E"
    assert gauge(60) == "60%"
    assert gauge(99) == "F"