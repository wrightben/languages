def main():
	print(gauge(prompt("Fraction: ")))


def prompt(prompt):
	while True:
		try:
			_ = input(prompt).strip().lower()
			return convert(_)
		except:
			pass


def convert(fraction):
	if type(fraction) != str:
		raise TypeError

	components = fraction.partition("/")
	if components[1] == "":
		raise ValueError

	try:
		a = int(components[0])
		b = int(components[2])
	except:
		raise ValueError

	if a > b:
		raise ValueError

	if b == 0:
		raise ZeroDivisionError


	return int(round((a/b)*100,0))


def gauge(percentage):
	if type(percentage) != int:
		raise TypeError

	if percentage <= 1:
		return "E"
	elif percentage >=99:
		return "F"
	else:
		return f"{percentage}%"


if __name__ == "__main__":
    main()



'''
VAL="test_fuel"; mkdir "${VAL}"; cd "${VAL}"; code "${VAL}.py"

check50 "cs50/problems/2022/python/${VAL}"
submit50 "cs50/problems/2022/python/${VAL}"
'''